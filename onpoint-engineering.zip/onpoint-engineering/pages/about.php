<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About | OnPoint Civils</title>
  <meta name="description" content="About OnPoint Civils, a civil engineering and construction company.">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800&family=Manrope:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
  <header class="site-header">
    <div class="container nav">
      <a href="../index.php" class="logo"><span class="logo-mark">O</span>OnPoint <span class="sub">Civils</span></a>
      <button class="menu-toggle" aria-label="Open menu" aria-expanded="false"><span></span><span></span><span></span></button>
      <ul class="nav-links">
        <li><a href="../index.php">Home</a></li>
        <li><a href="about.php" class="active">About</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="tel:+263782381986" class="btn">Call +263 78 238 1986</a></li>
      </ul>
    </div>
  </header>

  <section class="page-hero">
    <div class="container">
      <span class="label" style="color:var(--yellow)">About us</span>
      <h1>Engineers and builders you can rely on</h1>
      <p class="lead" style="color:#b7c1cd">OnPoint Civils is a civil engineering and construction company. We take on projects from design through to completion.</p>
    </div>
  </section>

  <section class="section">
    <div class="container split">
      <div class="reveal">
        <span class="label">Who we are</span>
        <h2>A practical approach to engineering</h2>
        <p style="margin-top:20px;color:var(--muted)">We work closely with our clients so that decisions are made quickly and everyone knows where the project stands.</p>
        <p style="margin-top:16px;color:var(--muted)">Our work covers roads, structures, water and sewer infrastructure, and buildings. Whatever the size of the job, we aim to plan it properly, price it fairly and build it well.</p>
      </div>
      <div class="reveal" style="--d:.1s">
        <div class="values">
          <div class="card"><h3>Safety</h3><p>No job is so urgent that it can't be done safely.</p></div>
          <div class="card"><h3>Quality</h3><p>Work is checked as it progresses, not only at the end.</p></div>
          <div class="card"><h3>Honesty</h3><p>Clear quotes, realistic timelines and regular updates.</p></div>
          <div class="card"><h3>Accountability</h3><p>We take responsibility for the work we do.</p></div>
        </div>
      </div>
    </div>
  </section>

  <section class="section dark" style="padding-bottom:0;overflow:hidden">
    <div class="container">
      <div class="section-head reveal">
        <span class="label">Our team</span>
        <h2>Our team</h2>
        <p class="lead">Our people work in protective equipment and follow clear safety procedures on site.</p>
      </div>
      <img src="../assets/images/team-machinery.png" alt="OnPoint Civils team in safety gear with an excavator and tipper truck" class="people-img reveal" loading="lazy">
    </div>
  </section>

  <section class="cta-band">
    <div class="container">
      <div>
        <h2>Let's talk about your project</h2>
        <p>Call, WhatsApp or send us a message.</p>
      </div>
      <a href="contact.php" class="btn btn-dark">Contact us</a>
    </div>
  </section>

  <footer class="site-footer">
    <div class="container">
      <div class="footer-grid">
        <div class="footer-about">
          <a href="../index.php" class="logo"><span class="logo-mark">O</span>OnPoint <span class="sub">Civils</span></a>
          <p>Civil engineering and construction.</p>
        </div>
        <div><h5>Pages</h5><ul><li><a href="../index.php">Home</a></li><li><a href="about.php">About</a></li><li><a href="contact.php">Contact</a></li></ul></div>
        <div><h5>Phone</h5><ul><li><a href="tel:+263782381986">+263 78 238 1986</a></li><li><a href="tel:+263788094724">+263 78 809 4724</a></li><li><a href="tel:+263712734834">+263 71 273 4834</a></li><li><a href="tel:+263242328474">242 328474/5</a></li></ul></div>
        <div><h5>WhatsApp</h5><ul><li><a href="https://wa.me/263782381986" target="_blank" rel="noopener">+263 78 238 1986</a></li><li><a href="https://wa.me/263788094724" target="_blank" rel="noopener">+263 78 809 4724</a></li></ul></div>
      </div>
      <div class="footer-bottom">© <span data-year>2026</span> OnPoint Civils</div>
    </div>
  </footer>

  <script src="../assets/js/main.js"></script>
</body>
</html>
