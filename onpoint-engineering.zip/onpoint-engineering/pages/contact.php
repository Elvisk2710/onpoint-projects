<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact | OnPoint Civils</title>
  <meta name="description" content="Contact OnPoint Civils by phone or WhatsApp.">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800&family=Manrope:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
  <header class="site-header">
    <div class="container nav">
      <a href="../index.php" class="logo"><span class="logo-mark">O</span>OnPoint <span class="sub">Civils</span></a>
      <button class="menu-toggle" aria-label="Open menu" aria-expanded="false"><span></span><span></span><span></span></button>
      <ul class="nav-links">
        <li><a href="../index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="contact.php" class="active">Contact</a></li>
        <li><a href="tel:+263782381986" class="btn">Call +263 78 238 1986</a></li>
      </ul>
    </div>
  </header>

  <section class="page-hero">
    <div class="container">
      <span class="label" style="color:var(--yellow)">Contact</span>
      <h1>Get in touch</h1>
      <p class="lead" style="color:#b7c1cd">Call, WhatsApp or fill in the form and we'll get back to you.</p>
    </div>
  </section>

  <section class="section alt">
    <div class="container contact-grid">
      <div class="info">
        <div class="info-item reveal">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 3h4l2 5-2.5 1.5a11 11 0 006 6L16 13l5 2v4a2 2 0 01-2 2A17 17 0 013 5a2 2 0 012-2z"/></svg>
          <div>
            <h4>Mobile</h4>
            <a href="tel:+263782381986">+263 78 238 1986</a>
            <a href="tel:+263788094724">+263 78 809 4724</a>
            <a href="tel:+263712734834">+263 71 273 4834</a>
          </div>
        </div>
        <div class="info-item reveal" style="--d:.1s">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9h10M7 13h6"/></svg>
          <div>
            <h4>Landline</h4>
            <p><a href="tel:+263242328474" style="display:inline">242 328474</a> / <a href="tel:+263242328475" style="display:inline">5</a></p>
          </div>
        </div>
        <div class="info-item reveal" style="--d:.2s">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 20l1.3-4A8 8 0 1112 20a8 8 0 01-4-1z"/></svg>
          <div>
            <h4>WhatsApp</h4>
            <a href="https://wa.me/263782381986" target="_blank" rel="noopener">+263 78 238 1986</a>
            <a href="https://wa.me/263788094724" target="_blank" rel="noopener">+263 78 809 4724</a>
          </div>
        </div>
      </div>

      <form class="form reveal" id="contactForm" data-wa="263782381986" style="--d:.1s">
        <h3>Send us a message</h3>
        <p>This opens WhatsApp with your message ready to send.</p>
        <div class="field-row">
          <div class="field"><label for="name">Name</label><input type="text" id="name" name="name" required></div>
          <div class="field"><label for="phone">Phone</label><input type="tel" id="phone" name="phone" required></div>
        </div>
        <div class="field">
          <label for="service">Service</label>
          <select id="service" name="service">
            <option>Roads</option>
            <option>Structures</option>
            <option>Water and Sewer</option>
            <option>Buildings</option>
            <option>Other</option>
          </select>
        </div>
        <div class="field"><label for="message">Message</label><textarea id="message" name="message" required></textarea></div>
        <button type="submit" class="btn btn-dark">Send on WhatsApp</button>
      </form>
    </div>
  </section>

  <footer class="site-footer">
    <div class="container">
      <div class="footer-grid">
        <div class="footer-about">
          <a href="../index.php" class="logo"><span class="logo-mark">O</span>OnPoint <span class="sub">Civils</span></a>
          <p>Civil engineering and construction.</p>
        </div>
        <div><h5>Pages</h5><ul><li><a href="../index.php">Home</a></li><li><a href="about.php">About</a></li><li><a href="contact.php">Contact</a></li></ul></div>
        <div><h5>Phone</h5><ul><li><a href="tel:+263782381986">+263 78 238 1986</a></li><li><a href="tel:+263788094724">+263 78 809 4724</a></li><li><a href="tel:+263712734834">+263 71 273 4834</a></li><li><a href="tel:+263242328474">242 328474/5</a></li></ul></div>
        <div><h5>WhatsApp</h5><ul><li><a href="https://wa.me/263782381986" target="_blank" rel="noopener">+263 78 238 1986</a></li><li><a href="https://wa.me/263788094724" target="_blank" rel="noopener">+263 78 809 4724</a></li></ul></div>
      </div>
      <div class="footer-bottom">© <span data-year>2026</span> OnPoint Civils</div>
    </div>
  </footer>

  <script src="../assets/js/main.js"></script>
</body>
</html>
