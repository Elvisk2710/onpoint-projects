<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Our Projects — OnPoint Civils</title>
  <meta name="description" content="Bridges, highways, water infrastructure and commercial buildings delivered by OnPoint Civils.">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400;1,500&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
  <div class="loader"><div class="logo-mark"><span>O</span></div></div>

  <header class="site-header">
    <div class="container nav">
      <a href="../index.php" class="logo"><div class="logo-mark"><span>O</span></div><div>OnPoint<small>Civils</small></div></a>
      <button class="menu-toggle" aria-label="Open menu" aria-expanded="false"><span></span><span></span><span></span></button>
      <ul class="nav-links">
        <li><a href="../index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="projects.php" class="active">Projects</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="contact.php" class="btn">Get a Quote</a></li>
      </ul>
    </div>
  </header>

  <section class="page-hero grain">
    <div class="blueprint"></div>
    <div class="glow glow-gold"></div>
    <div class="container" style="position:relative">
      <span class="eyebrow reveal in">Our Portfolio</span>
      <h1 class="split-words">Infrastructure that communities <em>depend on.</em></h1>
      <p class="lead reveal" style="--d:.4s">A selection of the bridges, roads, water systems and buildings we have engineered and constructed, each delivered safely and built to last.</p>
      <div class="breadcrumb reveal" style="--d:.5s"><a href="../index.php">Home</a><span>/</span><span>Projects</span></div>
    </div>
  </section>

  <section class="section section-light">
    <div class="container">
      <div class="filters reveal">
        <button class="filter active" data-filter="all">All Projects</button>
        <button class="filter" data-filter="completed">Completed</button>
        <button class="filter" data-filter="ongoing">Ongoing</button>
        <button class="filter" data-filter="planned">Planned</button>
      </div>

      <div class="projects-grid">
        <div class="project wide reveal" data-status="completed">
          <div class="visual reveal-mask"><div class="art">
            <svg viewBox="0 0 800 500" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="p1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2a3d63"/><stop offset="1" stop-color="#0b1220"/></linearGradient></defs><rect width="800" height="500" fill="url(#p1)"/><circle cx="600" cy="140" r="70" fill="#c9a24a" opacity=".25"/><path d="M0 330h800v10H0z" fill="#e8ecf4" opacity=".6"/><path d="M180 340V110h14v230zM606 340V110h14v230z" fill="#c9a24a" opacity=".8"/><path d="M0 250Q100 170 187 112Q400 380 613 112Q700 170 800 250" stroke="#e6c472" stroke-width="2" fill="none"/><g stroke="#e8ecf4" opacity=".3"><path d="M250 180V330M300 225V330M350 255V330M400 265V330M450 255V330M500 225V330M550 180V330M120 160V330M60 205V330M680 160V330M740 205V330"/></g></svg>
          </div></div>
          <span class="status"><i></i>Completed</span>
          <div class="meta"><span class="cat">Bridges &amp; Structures</span><h3>Riverside Crossing Bridge</h3><div class="loc">Structural rehabilitation and widening of a vital river crossing.</div></div>
        </div>

        <div class="project reveal" data-status="ongoing" style="--d:.1s">
          <div class="visual reveal-mask" style="--d:.1s"><div class="art">
            <svg viewBox="0 0 400 500" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="p2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a2f22"/><stop offset="1" stop-color="#0b1220"/></linearGradient></defs><rect width="400" height="500" fill="url(#p2)"/><path d="M110 500V140h90v360zM210 500V70h80v430z" fill="#18233b"/><g fill="#c9a24a" opacity=".55"><rect x="125" y="160" width="16" height="10"/><rect x="165" y="200" width="16" height="10"/><rect x="225" y="100" width="14" height="10"/><rect x="260" y="180" width="14" height="10"/><rect x="225" y="260" width="14" height="10"/></g><path d="M300 40V500M300 50H60M80 50v80" stroke="#e8833a" stroke-width="3" fill="none"/></svg>
          </div></div>
          <span class="status ongoing"><i></i>Ongoing</span>
          <div class="meta"><span class="cat">Commercial</span><h3>Meridian Office Park</h3><div class="loc">Multi-storey commercial complex with reinforced-concrete frame.</div></div>
        </div>

        <div class="project reveal" data-status="completed">
          <div class="visual reveal-mask"><div class="art">
            <svg viewBox="0 0 400 500" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="p3" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1e3350"/><stop offset="1" stop-color="#0b1220"/></linearGradient></defs><rect width="400" height="500" fill="url(#p3)"/><path d="M170 180L0 500h400L230 180z" fill="#111a2e"/><path d="M200 200v30M200 260v40M200 330v50M200 410v70" stroke="#e6c472" stroke-width="5"/><path d="M170 180L0 500M230 180l170 320" stroke="#e8ecf4" opacity=".35" stroke-width="2"/><circle cx="200" cy="110" r="40" fill="#c9a24a" opacity=".25"/></svg>
          </div></div>
          <span class="status"><i></i>Completed</span>
          <div class="meta"><span class="cat">Roads &amp; Highways</span><h3>Northern Corridor Highway</h3><div class="loc">Dual-carriageway upgrade with full drainage and safety works.</div></div>
        </div>

        <div class="project reveal" data-status="ongoing" style="--d:.1s">
          <div class="visual reveal-mask" style="--d:.1s"><div class="art">
            <svg viewBox="0 0 400 500" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="p5" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2b2a40"/><stop offset="1" stop-color="#0b1220"/></linearGradient></defs><rect width="400" height="500" fill="url(#p5)"/><g stroke="#c9a24a" stroke-width="2" fill="none" opacity=".8"><path d="M40 420h320M60 420V260h280v160M60 260l140-90 140 90"/><path d="M100 420V320h60v100M240 300h60v50h-60z"/></g><path d="M0 440h400" stroke="#e8ecf4" opacity=".3"/></svg>
          </div></div>
          <span class="status ongoing"><i></i>Ongoing</span>
          <div class="meta"><span class="cat">Institutional</span><h3>District Hospital Wing</h3><div class="loc">New medical wing with specialist structural and services design.</div></div>
        </div>

        <div class="project wide reveal" data-status="planned" style="--d:.2s">
          <div class="visual reveal-mask" style="--d:.2s"><div class="art">
            <svg viewBox="0 0 800 500" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="p4" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#173a45"/><stop offset="1" stop-color="#0b1220"/></linearGradient></defs><rect width="800" height="500" fill="url(#p4)"/><path d="M0 230Q400 170 800 230V500H0z" fill="#0f2a33"/><path d="M200 220L170 500H630L600 220z" fill="#18233b"/><g stroke="#e8ecf4" opacity=".25"><path d="M230 260h340M225 300h350M220 340h360M215 380h370"/></g><path d="M0 420q100-20 200 0t200 0 200 0 200 0" stroke="#4f8aa0" stroke-width="2" fill="none" opacity=".7"/></svg>
          </div></div>
          <span class="status"><i></i>Planned</span>
          <div class="meta"><span class="cat">Water Infrastructure</span><h3>Valley Reservoir &amp; Dam Wall</h3><div class="loc">Concrete gravity dam and treatment works for regional water supply.</div></div>
        </div>

        <div class="project reveal" data-status="completed">
          <div class="visual reveal-mask"><div class="art">
            <svg viewBox="0 0 400 500" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="p6" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1d3a3a"/><stop offset="1" stop-color="#0b1220"/></linearGradient></defs><rect width="400" height="500" fill="url(#p6)"/><g stroke="#4f8aa0" stroke-width="3" fill="none"><path d="M0 300h120v80h160v-80h120"/><circle cx="200" cy="340" r="26"/></g><g stroke="#c9a24a" opacity=".6"><path d="M60 300v-80M340 300v-80M60 220h280"/></g></svg>
          </div></div>
          <span class="status"><i></i>Completed</span>
          <div class="meta"><span class="cat">Water &amp; Sanitation</span><h3>Eastside Sewer Reticulation</h3><div class="loc">Trunk sewer and pump station serving a growing residential district.</div></div>
        </div>

        <div class="project reveal" data-status="planned" style="--d:.1s">
          <div class="visual reveal-mask" style="--d:.1s"><div class="art">
            <svg viewBox="0 0 400 500" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="p7" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a2530"/><stop offset="1" stop-color="#0b1220"/></linearGradient></defs><rect width="400" height="500" fill="url(#p7)"/><g fill="none" stroke="#e6c472" stroke-width="2"><path d="M40 440V200h100v240M160 440V120h100v320M280 440V240h80v200"/></g><g stroke="#e8ecf4" opacity=".2"><path d="M40 260h100M40 320h100M40 380h100M160 180h100M160 240h100M160 300h100M160 360h100M280 300h80M280 360h80"/></g></svg>
          </div></div>
          <span class="status"><i></i>Planned</span>
          <div class="meta"><span class="cat">Mixed-Use</span><h3>Harbour View Residences</h3><div class="loc">Mixed-use residential and retail development on a reclaimed site.</div></div>
        </div>
      </div>
    </div>
  </section>

  <section class="cta grain">
    <div class="blueprint"></div>
    <div class="glow glow-gold"></div>
    <div class="container" style="position:relative">
      <span class="eyebrow reveal">Your Project Next</span>
      <h2 class="split-words">Let's discuss how we can bring your <em>vision</em> to life.</h2>
      <div class="reveal" style="--d:.3s;display:flex;gap:16px;justify-content:center;flex-wrap:wrap">
        <a href="contact.php" class="btn">Get In Touch <span class="arrow">→</span></a>
        <a href="https://wa.me/263782381986" target="_blank" rel="noopener" class="btn btn-ghost">WhatsApp Us</a>
      </div>
    </div>
  </section>

  <footer class="site-footer">
    <div class="container">
      <div class="footer-grid">
        <div class="footer-about">
          <a href="../index.php" class="logo"><div class="logo-mark"><span>O</span></div><div>OnPoint<small>Civils</small></div></a>
          <p>Civil engineering and construction built on safety, precision and lasting confidence.</p>
        </div>
        <div><h5>Explore</h5><ul><li><a href="../index.php">Home</a></li><li><a href="about.php">About</a></li><li><a href="projects.php">Projects</a></li><li><a href="contact.php">Contact</a></li></ul></div>
        <div><h5>Call Us</h5><ul><li><a href="tel:+263782381986">+263 78 238 1986</a></li><li><a href="tel:+263788094724">+263 78 809 4724</a></li><li><a href="tel:+263712734834">+263 71 273 4834</a></li><li><a href="tel:+263242328474">Landline: 242 328474/5</a></li></ul></div>
        <div><h5>WhatsApp</h5><ul><li><a href="https://wa.me/263782381986" target="_blank" rel="noopener">+263 78 238 1986</a></li><li><a href="https://wa.me/263788094724" target="_blank" rel="noopener">+263 78 809 4724</a></li></ul></div>
      </div>
      <div class="footer-big">OnPoint Civils</div>
      <div class="footer-bottom"><span>© <span data-year>2026</span> OnPoint Civils. All rights reserved.</span><span>Safety · Precision · Confidence</span></div>
    </div>
  </footer>

  <script src="../assets/js/main.js"></script>
</body>
</html>
